const dbName = 'notes.db';
const dbVersion = 1;
const tableName = 'notes';
//-----------------------columns----------------
const colId = 'note_id';
const colText = 'note_text';
const colDate = 'created_date';
//-----------------Sql statements
const createTableSql =
    'create table $tableName ($colId integer primary key autoincrement, $colText text, $colDate text)';
